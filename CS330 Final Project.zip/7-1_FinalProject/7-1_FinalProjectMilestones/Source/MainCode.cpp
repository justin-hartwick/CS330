///////////////////////////////////////////////////////////////////////////////
// maincode.cpp
// CS 330 Final Project Application
// This file launches the 3D Pop Figure Display Scene and handles rendering.
///////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <cstdlib>

#include <GL/glew.h>
#include "GLFW/glfw3.h"

#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "SceneManager.h"
#include "ViewManager.h"
#include "ShapeMeshes.h"
#include "ShaderManager.h"

namespace
{
    const char* const WINDOW_TITLE = "7-1 Final Project and Milestones";

    GLFWwindow* g_Window = nullptr;
    SceneManager* g_SceneManager = nullptr;
    ShaderManager* g_ShaderManager = nullptr;
    ViewManager* g_ViewManager = nullptr;
}

// Forward declarations
bool InitializeGLFW();
bool InitializeGLEW();

int main(int argc, char* argv[])
{
    if (InitializeGLFW() == false)
        return EXIT_FAILURE;

    g_ShaderManager = new ShaderManager();
    g_ViewManager = new ViewManager(g_ShaderManager);
    g_Window = g_ViewManager->CreateDisplayWindow(WINDOW_TITLE);

    if (InitializeGLEW() == false)
        return EXIT_FAILURE;

    // Prime event system so glfwGetTime() and inputs start working immediately
    glfwPollEvents();
    glfwFocusWindow(g_Window);

    // Load and activate shaders
    g_ShaderManager->LoadShaders(
        "shaders/vertexShader.glsl",
        "shaders/fragmentShader.glsl");
    g_ShaderManager->use();

    // Initialize and prepare the 3D scene
    g_SceneManager = new SceneManager(g_ShaderManager);
    g_SceneManager->PrepareScene();

    // --- Main render loop ---
    while (!glfwWindowShouldClose(g_Window))
    {
        // Clear the color and depth buffers
        glEnable(GL_DEPTH_TEST);
        glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // ViewManager handles camera movement and projection each frame
        g_ViewManager->PrepareSceneView();

        // Draw the full 3D Pop Figure display scene
        g_SceneManager->RenderScene();

        // Swap buffers and process input events
        glfwSwapBuffers(g_Window);
        glfwPollEvents();
    }

    // Cleanup
    delete g_SceneManager;
    delete g_ViewManager;
    delete g_ShaderManager;

    glfwTerminate();
    return EXIT_SUCCESS;
}

// --- GLFW initialization ---
bool InitializeGLFW()
{
    if (!glfwInit())
    {
        std::cerr << "Failed to initialize GLFW" << std::endl;
        return false;
    }

#ifdef __APPLE__
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#else
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 6);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
#endif
    return true;
}

// --- GLEW initialization ---
bool InitializeGLEW()
{
    GLenum GLEWInitResult = glewInit();
    if (GLEW_OK != GLEWInitResult)
    {
        std::cerr << glewGetErrorString(GLEWInitResult) << std::endl;
        return false;
    }

    std::cout << "OpenGL successfully initialized\n";
    std::cout << "OpenGL Version: " << glGetString(GL_VERSION) << std::endl;
    return true;
}
