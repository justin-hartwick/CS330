﻿///////////////////////////////////////////////////////////////////////////////
// SceneManager.cpp
// Final Pop Figure Display Scene – Bookcase Environment
// Updated for CS 330 Final Project – Justin Hartwick
//
// Description:
// Controls the creation, transformation, and rendering of all 3D objects
// that make up the Pop Figure display scene. The scene includes textured
// figures, shelves, a floor surface, and a group of book spines with
// coordinated lighting. Lighting and material values are tuned to create
// a balanced look that highlights color and texture detail.
//
// NOTE:
// This version removes the duplicate local CameraRig class so the project
// uses the standard Milestone camera managed by ViewManager.cpp.
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"
#include "ShaderManager.h"

#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtx/transform.hpp>

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

namespace
{
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_UseTextureName = "bUseTexture";
}

// ---------------------------------------------------------------------------
// Texture Globals
// ---------------------------------------------------------------------------
GLuint texSkin = 0, texShoes = 0;
GLuint texHair1 = 0, texHair2 = 0, texHair3 = 0;
GLuint texShirt1 = 0, texShirt2 = 0, texShirt3 = 0;
GLuint texPants1 = 0, texPants2 = 0, texPants3 = 0;
GLuint texWood = 0;

// ---------------------------------------------------------------------------
// Texture loader
// ---------------------------------------------------------------------------
static GLuint LoadTexture(const char* path)
{
    int w, h, ch;
    stbi_set_flip_vertically_on_load(true);
    unsigned char* data = stbi_load(path, &w, &h, &ch, 0);
    if (!data)
    {
        printf("Warning: could not load texture: %s\n", path);
        return 0;
    }

    GLuint texID;
    glGenTextures(1, &texID);
    glBindTexture(GL_TEXTURE_2D, texID);

    GLenum fmt = (ch == 4) ? GL_RGBA : GL_RGB;
    glTexImage2D(GL_TEXTURE_2D, 0, fmt, w, h, 0, fmt, GL_UNSIGNED_BYTE, data);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    stbi_image_free(data);
    return texID;
}

// ---------------------------------------------------------------------------
// SceneManager setup
// ---------------------------------------------------------------------------
SceneManager::SceneManager(ShaderManager* sm)
{
    m_pShaderManager = sm;
    m_basicMeshes = new ShapeMeshes();
}

SceneManager::~SceneManager()
{
    delete m_basicMeshes;
    m_basicMeshes = nullptr;
}

// ---------------------------------------------------------------------------
// Transform helper
// ---------------------------------------------------------------------------
void SceneManager::SetTransformations(glm::vec3 s, float rx, float ry, float rz, glm::vec3 pos)
{
    glm::mat4 model =
        glm::translate(pos) *
        glm::rotate(glm::radians(rx), glm::vec3(1, 0, 0)) *
        glm::rotate(glm::radians(ry), glm::vec3(0, 1, 0)) *
        glm::rotate(glm::radians(rz), glm::vec3(0, 0, 1)) *
        glm::scale(s);
    m_pShaderManager->setMat4Value(g_ModelName, model);
}

// ---------------------------------------------------------------------------
// PrepareScene
// ---------------------------------------------------------------------------
void SceneManager::PrepareScene()
{
    m_basicMeshes->LoadPlaneMesh();
    m_basicMeshes->LoadBoxMesh();
    m_basicMeshes->LoadSphereMesh();
    m_basicMeshes->LoadCylinderMesh();
    m_basicMeshes->LoadPyramid4Mesh();

    texSkin = LoadTexture("textures/skin.png");
    texShoes = LoadTexture("textures/shoes.jpg");
    texHair1 = LoadTexture("textures/hair.png");
    texHair2 = LoadTexture("textures/darkwood.jpg");
    texHair3 = LoadTexture("textures/rusticwood.jpg");
    texShirt1 = LoadTexture("textures/shirt.jpg");
    texShirt2 = LoadTexture("textures/pumpkin.jpg");
    texShirt3 = LoadTexture("textures/cheddar.jpg");
    texPants1 = LoadTexture("textures/pants.jpg");
    texPants2 = LoadTexture("textures/knife_handle.jpg");
    texPants3 = LoadTexture("textures/base.jpg");
    texWood = LoadTexture("textures/drywall.jpg");

    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    glActiveTexture(GL_TEXTURE0);
    m_pShaderManager->setIntValue("objectTexture", 0);
}

// ---------------------------------------------------------------------------
// DrawPopFigureScaled
// ---------------------------------------------------------------------------
void SceneManager::DrawPopFigureScaled(glm::vec3 base, GLuint hairTex, GLuint shirtTex, GLuint pantsTex, float k)
{
    auto S = [k](glm::vec3 v) { return v * k; };

    // Pants
    glBindTexture(GL_TEXTURE_2D, pantsTex);
    m_pShaderManager->setIntValue(g_UseTextureName, true);
    SetTransformations(S(glm::vec3(0.32f, 1.15f, 0.32f)), 0, 0, 0, base + S(glm::vec3(-0.38f, -0.45f, 0.0f)));
    m_basicMeshes->DrawCylinderMesh();
    SetTransformations(S(glm::vec3(0.32f, 1.15f, 0.32f)), 0, 0, 0, base + S(glm::vec3(0.38f, -0.45f, 0.0f)));
    m_basicMeshes->DrawCylinderMesh();

    // Shirt
    glBindTexture(GL_TEXTURE_2D, shirtTex);
    SetTransformations(S(glm::vec3(1.25f, 0.9f, 1.05f)), 0, 0, 0, base + S(glm::vec3(0.0f, 0.8f, 0.0f)));
    m_basicMeshes->DrawBoxMesh();

    // Neck
    glBindTexture(GL_TEXTURE_2D, texSkin);
    SetTransformations(S(glm::vec3(0.6f, 0.25f, 0.6f)), 0, 0, 0, base + S(glm::vec3(0.0f, 1.55f, 0.0f)));
    m_basicMeshes->DrawBoxMesh();

    // Head
    glBindTexture(GL_TEXTURE_2D, texSkin);
    SetTransformations(S(glm::vec3(1.2f, 1.2f, 1.2f)), 0, 0, 0, base + S(glm::vec3(0.0f, 2.5f, 0.0f)));
    m_basicMeshes->DrawSphereMesh();

    // Hair
    glBindTexture(GL_TEXTURE_2D, hairTex);
    SetTransformations(S(glm::vec3(1.3f, 0.65f, 1.3f)), 0, 0, 0, base + S(glm::vec3(0.0f, 3.1f, 0.0f)));
    m_basicMeshes->DrawSphereMesh();

    // Eyes and nose (solid color)
    m_pShaderManager->setIntValue(g_UseTextureName, false);
    m_pShaderManager->setVec4Value(g_ColorValueName, glm::vec4(0.05f, 0.05f, 0.05f, 1.0f));
    SetTransformations(S(glm::vec3(0.12f)), 0, 0, 0, base + S(glm::vec3(-0.35f, 2.65f, 1.15f)));
    m_basicMeshes->DrawSphereMesh();
    SetTransformations(S(glm::vec3(0.12f)), 0, 0, 0, base + S(glm::vec3(0.35f, 2.65f, 1.15f)));
    m_basicMeshes->DrawSphereMesh();

    m_pShaderManager->setVec4Value(g_ColorValueName, glm::vec4(0.95f, 0.6f, 0.6f, 1.0f));
    SetTransformations(S(glm::vec3(0.2f)), 0, 0, 0, base + S(glm::vec3(0.0f, 2.55f, 1.25f)));
    m_basicMeshes->DrawPyramid4Mesh();

    // Shoes
    glBindTexture(GL_TEXTURE_2D, texShoes);
    m_pShaderManager->setIntValue(g_UseTextureName, true);
    SetTransformations(S(glm::vec3(0.36f, 0.25f, 0.55f)), 0, 0, 0, base + S(glm::vec3(-0.38f, -0.8f, 0.25f)));
    m_basicMeshes->DrawBoxMesh();
    SetTransformations(S(glm::vec3(0.36f, 0.25f, 0.55f)), 0, 0, 0, base + S(glm::vec3(0.38f, -0.8f, 0.25f)));
    m_basicMeshes->DrawBoxMesh();
}

// ---------------------------------------------------------------------------
// RenderScene – draws full Pop Figure display and aligned bookcase
// ---------------------------------------------------------------------------
void SceneManager::RenderScene()
{
    ///////////////////////////////////////////////////////////////////////////
    // LIGHTING SETUP
    ///////////////////////////////////////////////////////////////////////////

    // Base ambient / directional lights
    m_pShaderManager->setVec3Value("lightPos", glm::vec3(5.0f, 4.0f, 5.0f));
    m_pShaderManager->setVec3Value("lightColor", glm::vec3(1.0f, 0.9f, 0.8f));

    // Secondary colored light (adds warmth)
    m_pShaderManager->setVec3Value("lightPos2", glm::vec3(-4.0f, 6.0f, 3.0f));
    m_pShaderManager->setVec3Value("lightColor2", glm::vec3(1.0f, 0.6f, 1.4f));

    // Scene-wide ambient and material properties
    m_pShaderManager->setVec3Value("ambientColor", glm::vec3(0.22f, 0.22f, 0.25f));
    m_pShaderManager->setFloatValue("specularStrength", 0.6f);
    m_pShaderManager->setFloatValue("shininess", 32.0f);

  // ---------------------------------------------------------------------------
  // Final spotlight alignment – centered directly above each Pop Figure
  // ---------------------------------------------------------------------------
    glm::vec3 spotPositions[3] = {
        glm::vec3(-2.3f, 8.4f, 1.5f),   // Left – nudged slightly more inward
        glm::vec3(0.0f, 8.4f, 1.8f),   // Center – unchanged
        glm::vec3(2.3f, 8.4f, 1.5f)    // Right – nudged slightly more inward
    };

    glm::vec3 spotColors[3] = {
        glm::vec3(1.0f, 0.97f, 0.85f),  // warm
        glm::vec3(1.0f, 1.0f, 0.9f),    // neutral
        glm::vec3(0.95f, 0.98f, 1.0f)   // cool
    };

    // Narrow, crisp cone angles
    float cutoffAngle = glm::cos(glm::radians(6.0f));
    float outerCutoffAngle = glm::cos(glm::radians(9.0f));

    // Send spotlight values to the shader
    for (int i = 0; i < 3; i++)
    {
        std::string base = "spotLights[" + std::to_string(i) + "]";
        m_pShaderManager->setVec3Value((base + ".position").c_str(), spotPositions[i]);
        m_pShaderManager->setVec3Value((base + ".color").c_str(), spotColors[i]);
        m_pShaderManager->setFloatValue((base + ".cutoff").c_str(), cutoffAngle);
        m_pShaderManager->setFloatValue((base + ".outerCutoff").c_str(), outerCutoffAngle);
    }

    ///////////////////////////////////////////////////////////////////////////
    // BACKGROUND WALL
    ///////////////////////////////////////////////////////////////////////////
    m_pShaderManager->setIntValue(g_UseTextureName, false);
    m_pShaderManager->setVec4Value(g_ColorValueName, glm::vec4(0.58f, 0.66f, 0.56f, 1.0f));
    SetTransformations(glm::vec3(10.0f, 10.0f, 0.2f), 0, 0, 0, glm::vec3(0.0f, 1.0f, -2.0f));
    m_basicMeshes->DrawBoxMesh();

    ///////////////////////////////////////////////////////////////////////////
    // SHELVES AND FLOOR
    ///////////////////////////////////////////////////////////////////////////
    const float shelfWidth = 20.0f;
    const float shelfDepth = 2.0f;
    const float shelfThickness = 0.35f;
    const float topShelfY = 2.0f;
    const float bottomShelfY = -2.5f;

    m_pShaderManager->setIntValue(g_UseTextureName, true);
    glBindTexture(GL_TEXTURE_2D, texPants3); // light wood texture

    // Top shelf
    SetTransformations(glm::vec3(shelfWidth / 2.0f, shelfThickness, shelfDepth / 2.0f), 0, 0, 0,
        glm::vec3(0.0f, topShelfY, 0.3f));
    m_basicMeshes->DrawBoxMesh();

    // Bottom shelf
    SetTransformations(glm::vec3(shelfWidth / 2.0f, shelfThickness, shelfDepth / 2.0f), 0, 0, 0,
        glm::vec3(0.0f, bottomShelfY, 0.3f));
    m_basicMeshes->DrawBoxMesh();

    // Floor base
    glBindTexture(GL_TEXTURE_2D, texHair3); // darker wood
    SetTransformations(glm::vec3(12.0f, 0.25f, 6.0f), 0, 0, 0,
        glm::vec3(0.0f, bottomShelfY - 2.0f, 0.0f));
    m_basicMeshes->DrawBoxMesh();

    ///////////////////////////////////////////////////////////////////////////
    // POP FIGURES (3 Total)
    ///////////////////////////////////////////////////////////////////////////
    const float figureScale = 0.45f;
    const float boxHeight = 6.0f;
    const float boxZ = 0.3f;
    const float padThickness = 0.05f;
    const float padRadius = 0.65f;

    glm::vec3 positions[3] = {
        glm::vec3(-2.5f, topShelfY + 0.35f, boxZ),
        glm::vec3(0.0f, topShelfY + 0.35f, boxZ),
        glm::vec3(2.5f, topShelfY + 0.35f, boxZ)
    };

    GLuint hairTex[3] = { texHair1, texHair2, texHair3 };
    GLuint shirtTex[3] = { texShirt1, texShirt2, texShirt3 };
    GLuint pantsTex[3] = { texPants1, texPants2, texPants3 };

    for (int i = 0; i < 3; i++)
    {
        // Base pad
        m_pShaderManager->setIntValue(g_UseTextureName, false);
        m_pShaderManager->setVec4Value(g_ColorValueName, glm::vec4(0.08f, 0.08f, 0.08f, 1.0f));
        SetTransformations(glm::vec3(padRadius, padThickness, padRadius),
            0, 0, 0, glm::vec3(positions[i].x, topShelfY + 0.45f, boxZ));
        m_basicMeshes->DrawCylinderMesh();

        // Acrylic display box
        glDepthMask(GL_FALSE);
        m_pShaderManager->setVec4Value(g_ColorValueName, glm::vec4(0.85f, 0.95f, 1.0f, 0.22f));
        SetTransformations(glm::vec3(1.4f, boxHeight / 2.0f, 1.2f),
            0, 0, 0, glm::vec3(positions[i].x, topShelfY + (boxHeight / 2.0f) - 1.1f, boxZ));
        m_basicMeshes->DrawBoxMesh();
        glDepthMask(GL_TRUE);

        // Pop Figure itself
        glEnable(GL_BLEND);
        m_pShaderManager->setIntValue(g_UseTextureName, true);
        m_pShaderManager->setVec4Value(g_ColorValueName, glm::vec4(1.0f));
        float raisedY = topShelfY + 0.65f + (0.15f * 0.65f) + (0.20f * 0.65f);
        DrawPopFigureScaled(glm::vec3(positions[i].x, raisedY, boxZ),
            hairTex[i], shirtTex[i], pantsTex[i], figureScale);
    }

    ///////////////////////////////////////////////////////////////////////////
    // BOOKS AND BACK BLOCK
    ///////////////////////////////////////////////////////////////////////////
    const float bookBaseZ = 0.3f;
    const float bookBaseHeight = 3.8f;
    const float bookBaseDepth = 0.9f;
    const float lowerOffset = -0.55f;
    const float forwardShift = 0.55f;
    const float spineWidth = 0.80f;
    const int spineCount = 10;

    const float bookBaseWidth = (spineCount + 8) * spineWidth;
    const float moveRightX = -2.1f + (2.0f * spineWidth);
    const float spineDepth = bookBaseDepth * 1.25f;

    glBindTexture(GL_TEXTURE_2D, texWood);
    m_pShaderManager->setIntValue(g_UseTextureName, true);

    float baseY = bottomShelfY + 0.35f + (bookBaseHeight * 0.5f) + lowerOffset;
    SetTransformations(glm::vec3(bookBaseWidth * 0.5f, bookBaseHeight * 0.5f, bookBaseDepth * 0.5f),
        0.0f, 0.0f, 0.0f, glm::vec3(moveRightX, baseY, bookBaseZ + forwardShift));
    m_basicMeshes->DrawBoxMesh();

    // Individual book spines
    const float blockLeftX = moveRightX - (bookBaseWidth * 0.5f);
    float spineCenterX = blockLeftX + (spineWidth * 4.5f);

    GLuint spineTexPool[] = {
        LoadTexture("textures/cheese_wheel.jpg"),
        LoadTexture("textures/breadcrust.jpg"),
        LoadTexture("textures/tilesf2.jpg"),
        LoadTexture("textures/pumpkin.jpg"),
        LoadTexture("textures/knife_handle.jpg"),
        LoadTexture("textures/stainedglass.jpg"),
        LoadTexture("textures/darkwood.jpg"),
        LoadTexture("textures/base.jpg")
    };
    const int texPoolCount = sizeof(spineTexPool) / sizeof(spineTexPool[0]);

    for (int i = 0; i < spineCount; ++i)
    {
        glBindTexture(GL_TEXTURE_2D, spineTexPool[i % texPoolCount]);
        m_pShaderManager->setIntValue(g_UseTextureName, true);
        SetTransformations(glm::vec3(spineWidth * 0.5f, bookBaseHeight * 0.5f, spineDepth * 0.5f),
            0.0f, 0.0f, 0.0f, glm::vec3(spineCenterX, baseY, bookBaseZ + forwardShift));
        m_basicMeshes->DrawBoxMesh();
        spineCenterX += spineWidth;
    }
}
