///////////////////////////////////////////////////////////////////////////////
// SceneManager.h
// Header for my Pop Figure display scene
// Author: Justin Hartwick
// Date: October 2025
///////////////////////////////////////////////////////////////////////////////

#pragma once
#include "ShapeMeshes.h"
#include "ShaderManager.h"
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>

class SceneManager
{
public:
    SceneManager(ShaderManager* sm);
    ~SceneManager();

    // Main scene setup and rendering
    void PrepareScene();
    void RenderScene();

    // Camera and input management
    void InitInput(GLFWwindow* w);
    void UpdateView(GLFWwindow* win, float dt);

private:
    // Transformation helper for placing/scaling objects
    void SetTransformations(glm::vec3 scale, float rotX, float rotY, float rotZ, glm::vec3 pos);

    // Draws a Pop Figure model with given textures
    void DrawPopFigureScaled(glm::vec3 base, GLuint hairTex, GLuint shirtTex, GLuint pantsTex, float k);

    // Object and shader references
    ShapeMeshes* m_basicMeshes;
    ShaderManager* m_pShaderManager;
};
