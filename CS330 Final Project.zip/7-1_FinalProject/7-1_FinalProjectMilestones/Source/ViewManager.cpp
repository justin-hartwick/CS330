﻿///////////////////////////////////////////////////////////////////////////////
// ViewManager.cpp
// ============
// Manages the viewing of 3D objects within the viewport - camera, projection.
//
// AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
// UPDATED BY: Justin Hartwick
// DATE: October 2025
//
// Notes:
// • Handles the OpenGL display window, camera movement, and projection setup.
// • Starts farther back for larger scene, with optional Shift speed boost.
// • Added Q/E vertical motion and P-key orthographic toggle.
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <iostream>
using namespace std;

namespace
{
    const int WINDOW_WIDTH = 1000;
    const int WINDOW_HEIGHT = 800;
    const char* g_ViewName = "view";
    const char* g_ProjectionName = "projection";

    Camera* g_pCamera = nullptr;

    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;

    float gDeltaTime = 0.0f;
    float gLastFrame = 0.0f;
}

// ---------------------------------------------------------------------------
// Constructor
// ---------------------------------------------------------------------------
ViewManager::ViewManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_pWindow = nullptr;
    g_pCamera = new Camera();

    g_pCamera->Position = glm::vec3(0.0f, 5.0f, 20.0f);
    g_pCamera->Front = glm::vec3(0.0f, 0.0f, -1.0f);
    g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
    g_pCamera->Zoom = 80.0f;
    g_pCamera->MovementSpeed = 60.0f;
}

// ---------------------------------------------------------------------------
// Destructor
// ---------------------------------------------------------------------------
ViewManager::~ViewManager()
{
    m_pShaderManager = nullptr;
    m_pWindow = nullptr;

    if (g_pCamera != nullptr)
    {
        delete g_pCamera;
        g_pCamera = nullptr;
    }
}

// ---------------------------------------------------------------------------
// CreateDisplayWindow()
// ---------------------------------------------------------------------------
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
    GLFWwindow* window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, windowTitle, nullptr, nullptr);
    if (window == nullptr)
    {
        cout << "Failed to create GLFW window" << endl;
        glfwTerminate();
        return nullptr;
    }

    glfwMakeContextCurrent(window);
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
    glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    m_pWindow = window;
    return window;
}

// ---------------------------------------------------------------------------
// Mouse_Position_Callback()
// ---------------------------------------------------------------------------
void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos)
{
    if (gFirstMouse)
    {
        gLastX = static_cast<float>(xMousePos);
        gLastY = static_cast<float>(yMousePos);
        gFirstMouse = false;
    }

    float xOffset = static_cast<float>(xMousePos - gLastX);
    float yOffset = static_cast<float>(gLastY - yMousePos);
    gLastX = static_cast<float>(xMousePos);
    gLastY = static_cast<float>(yMousePos);

    g_pCamera->ProcessMouseMovement(xOffset, yOffset);
}

// ---------------------------------------------------------------------------
// ProcessKeyboardEvents()
// ---------------------------------------------------------------------------
void ViewManager::ProcessKeyboardEvents()
{
    if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(m_pWindow, true);

    // --- Shift Speed Boost ---
    float speedBoost = (glfwGetKey(m_pWindow, GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS) ? 3.0f : 1.0f;
    g_pCamera->MovementSpeed = 60.0f * speedBoost;

    // Movement controls (WASD + QE)
    if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);

    // --- Vertical controls (rubric: Q/E) ---
    if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(DOWN, gDeltaTime);
    if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(UP, gDeltaTime);
}

// ---------------------------------------------------------------------------
// PrepareSceneView()
// ---------------------------------------------------------------------------
void ViewManager::PrepareSceneView()
{
    glm::mat4 view;
    glm::mat4 projection;

    float currentFrame = glfwGetTime();
    gDeltaTime = currentFrame - gLastFrame;
    gLastFrame = currentFrame;
    gDeltaTime = glm::min(gDeltaTime, 0.05f);

    ProcessKeyboardEvents();
    view = g_pCamera->GetViewMatrix();

    // --- Projection toggle (rubric: Perspective/Orthographic) ---
    static bool orthoMode = false;
    if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS)
        orthoMode = !orthoMode;

    if (orthoMode)
    {
        float aspect = static_cast<float>(WINDOW_WIDTH) / WINDOW_HEIGHT;
        float orthoScale = 12.0f;
        projection = glm::ortho(-orthoScale * aspect, orthoScale * aspect,
            -orthoScale, orthoScale, 0.1f, 300.0f);
    }
    else
    {
        projection = glm::perspective(glm::radians(g_pCamera->Zoom),
            static_cast<GLfloat>(WINDOW_WIDTH) / static_cast<GLfloat>(WINDOW_HEIGHT),
            0.1f, 300.0f);
    }

    if (m_pShaderManager != nullptr)
    {
        m_pShaderManager->setMat4Value(g_ViewName, view);
        m_pShaderManager->setMat4Value(g_ProjectionName, projection);
        m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
    }
}
